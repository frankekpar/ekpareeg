# Dataset For A Novel Three-dimensional Multilayer Electroencephalography Paradigm
---

This dataset contains raw electroencephalography (EEG) data recorded using the Emotiv EPOC wireless EEG headset 
attached to a novel sensor ensemble permitting simultaneous capture of distinct EEG signal streams from multiple neuronal 
population layers.

It provides support for falsification of the null hypothesis stated below and validation of the alternative
hypothesis, also stated below.

Null Hypothesis:
Multiple electrodes or sensors placed at distinct layers within the same sensor ensemble record identical or 
similar EEG signal streams when placed above the same location on the scalp.

Alternative Hypothesis:
Multiple electrodes or sensors placed at distinct layers within the same sensor ensemble record distinct EEG 
signal streams when placed above the same location on the scalp.




## Description of the data and file structure

The dataset comprises three (3) separate files each containing raw EEG data recordings from a human participant.
Each recording session lasted just over three (3) minutes or approximately 180000 milliseconds.
Informed consent was obtained from all participants. The studies complied with all relevant ethical regulations
and were approved by the Research Ethics Committee at Topfaith University. All participants were healthy without 
any known history of neurological pathologies.

Each data file is a CSV (Comma Separated Values) file that can be opened with a suitable software tool such as
Microsoft Excel. 

The anonymized list of human participants and the corresponding raw EEG data file names are as
follows: Subject A: Filename: A-12.CSV; Subject B: Filename: B-12.CSV; Subject C: Filename: C-12.CSV.

The data is organized as a table with rows and columns.

The first row (ROW 1) of the data contains metadata such as the Subject Identifier and Title (anonymous letters 
and numbers such as A and 12) and labels (for example: COUNTER INTERPOLATED AF3 F7 F3 FC5, and so on) 
for each of the thirty-six (36) data channels (corresponding to similarly named date channels on the Emotiv EPOC) 
in the table in order of appearance in the columns of the table.

To clarify, the first column of the table contains data for the COUNTER data channel, the third column of the
table contains data for the AF3 data channel, the fifth column of the table contains data for the F3 data
channel, and so on.

Raw EEG data streams appear in the data channels labeled AF3, F7, F3, FC5, T7, P7, O1, O2, P8, T8, FC6, F4, F8
and AF4 --- representing the fourteen (14) EEG data channels or electrodes with corresponding names on the Emotiv EPOC.

For the studies reported here, only channels AF3 and F3 --- corresponding to the third and fifth columns 
(COLUMN 3 and COLUMN 5) of the table --- were recorded using the multilayer sensor ensemble. These were the
two electrodes specifically prepared for the recording sessions.

So the data analyzed in the studies appear in the third and fifth columns (COLUMN 3 and COLUMN 5) of the table 
and represent raw EEG data (in microvolts) from the EEG electrodes or channels labeled AF3 and F3 on the 
Emotiv EPOC wireless EEG headset.

***PLEASE NOTE THAT THE ACTUAL DATA BEGIN FROM THE SECOND ROW (ROW 2) OF THE TABLE AS THE FIRST ROW IS DEDICATED 
TO METADATA AS EXPLAINED EARLIER.***